import { store } from './_store.js';
export const config = { path: "/api/photos" };

export async function handler() {
  try {
    const s = store('photo-features');
    const list = await s.list();
    const feats = [];
    for (const k of list.blobs) {
      const txt = await s.get(k.key, { type: 'text' });
      try { feats.push(JSON.parse(txt)); } catch {}
    }
    return { statusCode: 200, headers:{ 'content-type':'application/json' },
      body: JSON.stringify({ type:'FeatureCollection', features: feats }) };
  } catch (e) {
    return { statusCode: 500, body: 'photos error: ' + e.message };
  }
}
