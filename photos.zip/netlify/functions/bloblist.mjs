// netlify/functions/bloblist.mjs
import { store } from './_store.js';
export const config = { path: "/api/bloblist" };

// GET /api/bloblist?store=photos  (or pins, photo-features)
// Returns: { blobs: [{ key, size, createdAt }, ...] }
export async function handler(event) {
  try {
    const url = new URL(event.rawUrl);
    const storeName = url.searchParams.get('store');
    if (!storeName) return { statusCode: 400, body: 'store required' };

    const s = store(storeName);
    const list = await s.list();

    return {
      statusCode: 200,
      headers: { 'content-type': 'application/json' },
      body: JSON.stringify(list)
    };
  } catch (e) {
    return { statusCode: 500, body: 'error: ' + e.message };
  }
}
