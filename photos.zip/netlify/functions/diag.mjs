// netlify/functions/diag.mjs
import { getStore } from '@netlify/blobs';
import { store } from './_store.js';
export const config = { path: "/api/diag" };

export async function handler() {
  const siteID = process.env.NETLIFY_SITE_ID || process.env.SITE_ID || null;
  const token  = process.env.NETLIFY_AUTH_TOKEN || process.env.BLOBS_TOKEN || process.env.NETLIFY_API_TOKEN || null;

  const env = {
    hasNETLIFY_SITE_ID: !!siteID,
    siteIDPrefix: siteID ? siteID.slice(0, 8) : null,
    hasToken: !!token,
    tokenLen: token ? String(token).length : 0
  };

  const results = {
    auto: { ok: false, err: null },
    manual_name_opts: { ok: false, err: null },
    manual_object: { ok: false, err: null },
    helper: { ok: false, err: null }
  };

  // 1) auto
  try {
    const s = getStore('diag');
    await s.list();
    results.auto.ok = true;
  } catch (e) { results.auto.err = String(e?.message || e); }

  // 2) manual (name, {siteID, token})
  try {
    const s = getStore('diag', { siteID, token });
    await s.list();
    results.manual_name_opts.ok = true;
  } catch (e) { results.manual_name_opts.err = String(e?.message || e); }

  // 3) manual ({ name, siteID, token })
  try {
    const s = getStore({ name: 'diag', siteID, token });
    await s.list();
    results.manual_object.ok = true;
  } catch (e) { results.manual_object.err = String(e?.message || e); }

  // 4) our helper (tries all)
  try {
    const s = store('diag');
    await s.set('diag_test.json', JSON.stringify({ ok: true, ts: Date.now() }), { contentType: 'application/json' });
    const list = await s.list();
    results.helper.ok = Array.isArray(list?.blobs);
  } catch (e) { results.helper.err = String(e?.message || e); }

  return {
    statusCode: 200,
    headers: { 'content-type': 'application/json' },
    body: JSON.stringify({ env, results }, null, 2)
  };
}
