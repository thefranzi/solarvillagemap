import { store } from './_store.js';
export const config = { path: "/api/pins" };

const STORE = 'pins';

async function readAll(s) {
  const list = await s.list();
  const feats = [];
  for (const k of list.blobs) {
    const txt = await s.get(k.key, { type: 'text' });
    try { feats.push(JSON.parse(txt)); } catch {}
  }
  return { type: 'FeatureCollection', features: feats };
}

export async function handler(event) {
  try {
    const s = store(STORE);

    if (event.httpMethod === 'GET') {
      const fc = await readAll(s);
      return { statusCode: 200, headers: { 'content-type': 'application/json' }, body: JSON.stringify(fc) };
    }

    if (event.httpMethod === 'POST') {
      const feature = JSON.parse(event.body);
      if (feature?.geometry?.type !== 'Point') return { statusCode: 400, body: 'Point feature required' };
      const id = 'pin_' + Date.now();
      await s.set(`${id}.json`, JSON.stringify(feature), { contentType: 'application/json' });
      return { statusCode: 200, headers: { 'content-type': 'application/json' }, body: JSON.stringify(feature) };
    }

    return { statusCode: 405, body: 'Method Not Allowed' };
  } catch (e) {
    return { statusCode: 500, body: 'pins error: ' + e.message };
  }
}
