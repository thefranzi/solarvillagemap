// netlify/functions/_store.js
// Robust helper so Blobs works regardless of SDK signature.
// Tries auto-context, then manual with (name, opts), then manual with ({ name, ... }).

import { getStore } from '@netlify/blobs';

function readEnv() {
  // Prefer standard names; allow alternates too
  const siteID = process.env.NETLIFY_SITE_ID || process.env.SITE_ID || process.env.SITE_ID_OVERRIDE;
  const token  = process.env.NETLIFY_AUTH_TOKEN || process.env.BLOBS_TOKEN || process.env.NETLIFY_API_TOKEN;
  return { siteID, token };
}

export function store(name) {
  // 1) Try auto-injected context (works on Netlify cloud / netlify dev when available)
  try {
    return getStore(name);
  } catch (e1) {
    // 2) Try manual credentials (two-arg signature)
    const { siteID, token } = readEnv();
    if (!siteID || !token) throw e1;

    try {
      // Old/new SDK often supports this signature:
      // getStore(name, { siteID, token })
      return getStore(name, { siteID, token });
    } catch (e2) {
      // 3) Try object signature used by some SDK versions:
      // getStore({ name, siteID, token })
      try {
        return getStore({ name, siteID, token });
      } catch (e3) {
        // Preserve the most-informative error (include both forms for clarity)
        const msg = [
          'Blobs getStore failed.',
          `auto: ${e1?.message || e1}`,
          `manual(name,opts): ${e2?.message || e2}`,
          `manual({name,...}): ${e3?.message || e3}`,
          `env: siteID=${siteID ? siteID.slice(0,8)+'…' : 'MISSING'} token=${token ? 'SET' : 'MISSING'}`
        ].join(' | ');
        const err = new Error(msg);
        err.name = 'BlobsStoreInitError';
        throw err;
      }
    }
  }
}
