// netlify/functions/photo.mjs
import { store } from './_store.js';
export const config = { path: "/api/photo/*" };

// Streams an image from the "photos" store at /api/photo/<key>
export async function handler(event) {
  try {
    const key = event.path.replace(/^\/?api\/photo\/?/, "");
    if (!key) return { statusCode: 400, body: "missing key" };

    const s = store('photos');
    const blob = await s.get(key, { type: 'stream' });
    if (!blob) return { statusCode: 404, body: "not found" };

    const ct = key.toLowerCase().endsWith('.png') ? 'image/png' : 'image/jpeg';
    return {
      statusCode: 200,
      headers: {
        'content-type': ct,
        'cache-control': 'public, max-age=31536000, immutable'
      },
      body: blob
    };
  } catch (e) {
    return { statusCode: 500, body: 'error: ' + e.message };
  }
}
