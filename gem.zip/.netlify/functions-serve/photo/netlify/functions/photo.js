var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// netlify/functions/photo.mjs
var photo_exports = {};
__export(photo_exports, {
  handler: () => handler
});
module.exports = __toCommonJS(photo_exports);
async function handler(event) {
  try {
    const parts = (event.path || "").split("/");
    const idx = parts.indexOf("photo");
    const key = idx >= 0 ? parts.slice(idx + 1).join("/") : "";
    if (!key) return { statusCode: 400, body: "missing key" };
    const owner = process.env.GH_OWNER;
    const repo = process.env.GH_REPO;
    const branch = process.env.GH_BRANCH || "main";
    const base = process.env.GH_IMAGES_DIR || "data/photos";
    const rawUrl = `https://raw.githubusercontent.com/${owner}/${repo}/${branch}/${base}/${key}`;
    return { statusCode: 302, headers: { location: rawUrl, "access-control-allow-origin": "*" } };
  } catch (e) {
    return { statusCode: 500, headers: { "content-type": "text/plain", "access-control-allow-origin": "*" }, body: e.stack || e.message };
  }
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handler
});
//# sourceMappingURL=photo.js.map
