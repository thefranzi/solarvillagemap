import { getStore } from '@netlify/blobs';
export const config = { path: "/api/photo/*" };

export async function handler(event) {
  try {
    // key is everything after /api/photo/
    const key = event.path.replace(/^\/?api\/photo\/?/, "");
    if (!key) return { statusCode: 400, body: "missing key" };

    const store = getStore('photos');
    const blob = await store.get(key, { type: 'stream' });
    if (!blob) return { statusCode: 404, body: "not found" };

    // naive content-type detection
    const ct = key.toLowerCase().endsWith('.png') ? 'image/png' : 'image/jpeg';
    return {
      statusCode: 200,
      headers: { 'content-type': ct, 'cache-control': 'public, max-age=31536000, immutable' },
      body: blob
    };
  } catch (e) {
    return { statusCode: 500, body: 'error: ' + e.message };
  }
}
